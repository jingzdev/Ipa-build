import SwiftUI
import UIKit

/// Simplified single-screen navigation: only Home is exposed in the app UI.
/// Existing feature implementations remain in the project, but are not shown
/// as top-level tabs.
struct ContentView: View {
    @EnvironmentObject private var patchStore: PatchProjectStore
    @EnvironmentObject private var repositoryStore: PackageRepositoryStore
    @State private var showSettings = false
    @State private var showLogs = false

    var body: some View {
        RepositoryHomeView(
            onOpenSettings: { showSettings = true },
            onOpenLogs: { showLogs = true }
        )
        .tint(AppTheme.accent)
        .imageScale(.small)
        .sheet(isPresented: $showSettings) {
            SettingsView()
        }
        .sheet(isPresented: $showLogs) {
            LogView()
        }
        .patchStorePresentation(patchStore)
        .repositoryStorePresentation(repositoryStore, patchStore: patchStore)
    }
}
